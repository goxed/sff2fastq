/* I N C L U D E S / C++ ******************************************************/
#include<fstream>
#include<string>
#include<sstream>
#include<iostream>
#include<vector>
#include<map>
#include<set>
#include <endian.h>
#include <stdint.h>
using namespace std;
#define WAITUSER    cerr<<endl<<"press return"; cin.ignore();
union len32{
  uint32_t lenBE;
  char lenCharArr[4];
} readLen32;
