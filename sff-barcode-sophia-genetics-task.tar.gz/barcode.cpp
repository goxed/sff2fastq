#include "barcode.h"

unsigned copy_sff_header(char * sff_file, unsigned int sffFileNameLen,  \
		      unsigned int headerBytes, string outputSffFileName)
{
    ifstream sffFileIn;
    string sffFileName(sff_file, sffFileNameLen);
    sffFileIn.open(sffFileName.c_str(), ios::in | ios::binary);
    char *headerData;
    if(sffFileIn.is_open()){
      headerData=new char[headerBytes];
      sffFileIn.read(headerData,headerBytes);
    }
    else{
      return 0;
    }
    sffFileIn.close();
    ofstream sffFileOut;
    sffFileOut.open(outputSffFileName.c_str(), ios::out | ios::binary | ios::trunc);
    if(sffFileOut.is_open()){
       sffFileOut.write(headerData,headerBytes);
       delete [] headerData;
    }
    else{
      delete [] headerData;
      return 0;
    }
    sffFileOut.close();
    return 1;
}

unsigned copy_sff_header_and_read(char *sff_file, unsigned int sffFileNameLen, \
			  unsigned long int sffFileBytesRead, unsigned int readHeaderBytes, \
			  unsigned int readDataBytes, string outputSffFileName)
{
    ifstream sffFileIn;
    string sffFileName(sff_file, sffFileNameLen);
    sffFileIn.open(sffFileName.c_str(), ios::in | ios::binary);
    int fileReadPos=sffFileBytesRead-readDataBytes-readHeaderBytes;
    if(fileReadPos<0){
      sffFileIn.close();
      return 0;
    }
    sffFileIn.seekg(fileReadPos);
    
    char *readHeaderData;
    char *readData;
    if(sffFileIn.is_open()){
      readHeaderData=new char[readHeaderBytes];
      sffFileIn.read(readHeaderData, readHeaderBytes);
      readData=new char[readDataBytes];
      sffFileIn.read(readData, readDataBytes);
    }
    else{
      return 0;
    }
    sffFileIn.close();
    ofstream sffFileOut;
    sffFileOut.open(outputSffFileName.c_str(), ios::out | ios::binary | ios::app );
    if(sffFileOut.is_open()){
      sffFileOut.write(readHeaderData,readHeaderBytes);
      sffFileOut.write(readData, readDataBytes);
      delete[] readHeaderData;
      delete[] readData;
    }
    else{
       delete[] readHeaderData;
       delete[] readData;
       return 0;
    }
    sffFileOut.close();
    return 1;
}

unsigned read_barcodes(char * barcode_file, unsigned int barcodeFileNameLen, map<string,string> &barcodeMap, map<string,unsigned int> &barcodeCountMap, set<string::size_type> &barcodeLengthsSet)
{
    string barcodeFileName(barcode_file, barcodeFileNameLen);
    ifstream barcodeFile (barcodeFileName.c_str());
    if (!barcodeFile.is_open()){
	  cerr<<endl<<"Could not open the barcode list file "<<barcodeFileName; 
	  WAITUSER;
	  return 0;
    }
    string line;
    while(getline(barcodeFile,line)){
         stringstream ss_line (line);
         string barcodeName;
         ss_line>>barcodeName;
         string barcodeString;
         ss_line>>barcodeString;
         cout<<endl<<barcodeName<<"\t"<<barcodeString;
	 if(barcodeName.size()==0 || barcodeString.size()==0) continue;
	 barcodeLengthsSet.insert(barcodeString.size());
	 map<string,string>::iterator iB=barcodeMap.find(barcodeName);
	 if(iB==barcodeMap.end()){
		barcodeMap[barcodeString]=barcodeName;
		barcodeCountMap[barcodeString]=0;
	 }
    }
    for (set<string::size_type>::iterator s=barcodeLengthsSet.begin(); s!=barcodeLengthsSet.end(); ++s){
      cerr<<endl<<"Barcode Lengths="<<*s;
    }
    /*WAITUSER*/;
//     cerr<<endl<<"Min barcode length="<<*minBarcodeLen;
//     cerr<<endl<<"Max barcode length="<<maxBarcodeLen;
//     cerr<<endl<<"Total barcode count="<<barcodeMap.size();
    
//     map<string,string>::iterator iB=barcodeMap.find("CTAAGGTAAC");
//     
//     if(iB==barcodeMap.end()){
// 	cerr<<endl<<"NOT FOUND CTAAGGTAAC.";
//     }
//     else{
// 	cerr<<endl<<"Barcode Name = "<<(*iB).second;
//     }
}

unsigned write_barcode_sff_files_header(char * sff_file, unsigned int sffFileNameLen, unsigned int headerBytes, map <string,string> &barcodeMap){
  for (map<string,string>::iterator b=barcodeMap.begin(); b!=barcodeMap.end(); ++b){
    string barcodeName = b->first;
    string barcodeString = b->second;
    if(!copy_sff_header(sff_file, sffFileNameLen, headerBytes, (barcodeName+".sff").c_str()) ){
 	  cerr<<endl<<"Failed to copy header "<< barcodeName;
     }
  }
  if(!copy_sff_header(sff_file, sffFileNameLen, headerBytes, "unassigned.sff") ){
 	  cerr<<endl<<"Failed to copy header "<< "unassigned.sff";
  }
  return 1;
}

unsigned update_barcode_sff_file_header(map<string,unsigned int> &barcodeCountMap, unsigned int unassignedReads){
  for(map<string, unsigned int>::iterator iB=barcodeCountMap.begin(); iB!=barcodeCountMap.end(); ++iB){
    string barcodeFileName = ((*iB).first)+".sff";
    unsigned int readCount = (*iB).second;
    cerr<<endl<<"Filename: "<<barcodeFileName<<"\t Counts \t"<<readCount;
    uint32_t readCountBE=htobe32(readCount);
    readLen32.lenBE=readCountBE;
    //cerr<<"\t"<<readCountBE<<"\t"<<be32toh(readCountBE);
    fstream sffFileStream;
    sffFileStream.open(barcodeFileName.c_str(), ios::binary | ios::out | ios::in );
    sffFileStream.seekp(20, ios::beg);
    sffFileStream.write(readLen32.lenCharArr, 4);
    sffFileStream.close();
  }
  {
    uint32_t readCountBE=htobe32(unassignedReads);
    readLen32.lenBE=readCountBE;
    fstream sffFileStream;
    sffFileStream.open("unassigned.sff", ios::binary | ios::out | ios::in );
    sffFileStream.seekp(20, ios::beg);
    sffFileStream.write(readLen32.lenCharArr, 4);
    sffFileStream.close();
  }
}
